package com.rehab.apiPayload.code;

public interface BaseCode {

	ReasonDTO getReason();

	ReasonDTO getReasonHttpStatus();
}
