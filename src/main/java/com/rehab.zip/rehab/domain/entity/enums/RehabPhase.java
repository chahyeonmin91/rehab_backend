package com.rehab.domain.entity.enums;

public enum RehabPhase {
    ACUTE,
    SUBACUTE,
    CHRONIC,
    MAINTENANCE
}
