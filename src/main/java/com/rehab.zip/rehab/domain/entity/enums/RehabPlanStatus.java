package com.rehab.domain.entity.enums;

public enum RehabPlanStatus {
    ACTIVE,
	INACTIVE,
    COMPLETED,
    PAUSED
}
