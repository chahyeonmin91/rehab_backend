package com.rehab.domain.entity.enums;

public enum MediaType {
    VIDEO,
    GIF
}
