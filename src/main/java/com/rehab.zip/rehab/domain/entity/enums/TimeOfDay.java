package com.rehab.domain.entity.enums;

public enum TimeOfDay {
    MORNING,
    LUNCH,
    DINNER,
    BEDTIME
}
