package com.rehab.domain.entity.enums;

public enum MedicationStatus {
    ACTIVE,
    COMPLETED,
    STOPPED
}
