package com.rehab.domain.entity.enums;

public enum ReminderChannel {
    PUSH,
    WEBPUSH,
    EMAIL,
    SMS
}
