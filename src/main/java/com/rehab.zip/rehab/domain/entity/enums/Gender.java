package com.rehab.domain.entity.enums;

public enum Gender {
    MALE,
    FEMALE,
    OTHER
}
