package com.rehab.domain.entity.enums;

public enum EvidenceLevel {
    A,  // 가장 높은 근거 수준
    B,
    C,
    D   // 가장 낮은 근거 수준
}
