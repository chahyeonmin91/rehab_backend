package com.rehab.domain.entity.enums;

public enum ExerciseLogStatus {
    COMPLETED,
    PARTIAL,
    SKIPPED
}
