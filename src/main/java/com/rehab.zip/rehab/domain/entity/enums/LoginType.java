package com.rehab.domain.entity.enums;

public enum LoginType {
	EMAIL,
	KAKAO,
	GOOGLE
}
