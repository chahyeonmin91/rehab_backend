package com.rehab.domain.entity.enums;

public enum ReminderType {
    EXERCISE,
    MEDICATION,
    GENERIC
}
