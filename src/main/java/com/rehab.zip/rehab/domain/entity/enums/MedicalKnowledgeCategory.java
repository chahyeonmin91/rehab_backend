package com.rehab.domain.entity.enums;

public enum MedicalKnowledgeCategory {
    GUIDELINE,
    PROTOCOL,
    RESEARCH,
    CONTRAINDICATION
}
