package com.rehab.domain.entity.enums;

public enum UserRole {
    USER,
    ADMIN
}
