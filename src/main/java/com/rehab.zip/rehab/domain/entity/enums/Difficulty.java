package com.rehab.domain.entity.enums;

public enum Difficulty {
    BEGINNER,
    INTERMEDIATE,
    ADVANCED
}
