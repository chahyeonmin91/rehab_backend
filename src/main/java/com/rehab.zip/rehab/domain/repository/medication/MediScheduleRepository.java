package com.rehab.domain.repository.medication;

import com.rehab.domain.entity.MediSchedule;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MediScheduleRepository extends JpaRepository<MediSchedule, Long> { }

